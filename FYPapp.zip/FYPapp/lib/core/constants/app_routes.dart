/// App route constants for named navigation
class AppRoutes {
  AppRoutes._();

  // Initial
  static const String splash = '/splash';

  // Onboarding
  static const String onboarding = '/onboarding';

  // Role Selection
  static const String roleSelection = '/role-selection';

  // Authentication
  static const String login = '/login'; // Admin login
  static const String userLogin = '/user-login'; // User login
  static const String signUp = '/signup'; // User signup
  static const String forgotPassword = '/forgot-password';

  // Main App
  static const String home = '/home';
  static const String userHome = '/user-home';
  static const String userManagement = '/user-management';
  static const String analytics = '/analytics';
  static const String signToText = '/sign-to-text';
  static const String textToSign = '/text-to-sign';
  static const String learning = '/learning';
  static const String learningCategory = '/learning/category';
  static const String learningDetail = '/learning/detail';
  static const String practice = '/practice';
  static const String quiz = '/quiz';
  static const String profile = '/profile';
  static const String settings = '/settings';
  static const String progressHistory = '/progress-history';
}

