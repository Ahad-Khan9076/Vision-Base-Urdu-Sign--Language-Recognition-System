import 'package:flutter/material.dart';

/// App color constants following Material 3 design standards
class AppColors {
  AppColors._();

  // Primary Colors
  static const Color primary = Color(0xFF6750A4);
  static const Color onPrimary = Color(0xFFFFFFFF);
  static const Color primaryContainer = Color(0xFFEADDFF);
  static const Color onPrimaryContainer = Color(0xFF21005D);

  // Secondary Colors
  static const Color secondary = Color(0xFF625B71);
  static const Color onSecondary = Color(0xFFFFFFFF);
  static const Color secondaryContainer = Color(0xFFE8DEF8);
  static const Color onSecondaryContainer = Color(0xFF1D192B);

  // Tertiary Colors
  static const Color tertiary = Color(0xFF7D5260);
  static const Color onTertiary = Color(0xFFFFFFFF);
  static const Color tertiaryContainer = Color(0xFFFFD8E4);
  static const Color onTertiaryContainer = Color(0xFF31111D);

  // Error Colors
  static const Color error = Color(0xFFBA1A1A);
  static const Color onError = Color(0xFFFFFFFF);
  static const Color errorContainer = Color(0xFFFFDAD6);
  static const Color onErrorContainer = Color(0xFF410002);

  // Background Colors
  static const Color background = Color(0xFFFFFBFE);
  static const Color onBackground = Color(0xFF1C1B1F);
  static const Color surface = Color(0xFFFFFBFE);
  static const Color onSurface = Color(0xFF1C1B1F);

  // Surface Variant
  static const Color surfaceVariant = Color(0xFFE7E0EC);
  static const Color onSurfaceVariant = Color(0xFF49454F);

  // Outline
  static const Color outline = Color(0xFF79747E);
  static const Color outlineVariant = Color(0xFFCAC4D0);

  // Shadow
  static const Color shadow = Color(0xFF000000);

  // Success
  static const Color success = Color(0xFF4CAF50);
  static const Color onSuccess = Color(0xFFFFFFFF);

  // Warning
  static const Color warning = Color(0xFFFF9800);
  static const Color onWarning = Color(0xFFFFFFFF);

  // Info
  static const Color info = Color(0xFF2196F3);
  static const Color onInfo = Color(0xFFFFFFFF);

  // Design-specific colors from Figma
  static const Color orange = Color(0xFFFF6B35); // Orange button color
  static const Color lightBlue =
      Color(0xFF567DF4); // Light blue button color (updated)
  static const Color darkBlue =
      Color(0xFF567DF4); // Dark blue text color (updated)
  static const Color lightBlueText =
      Color(0xFF567DF4); // Lighter blue text (updated)
  static const Color beigeBackground =
      Color(0xFFF5F5DC); // Light beige background
  static const Color handBlue =
      Color(0xFF567DF4); // Blue for hand icon (updated)
  static const Color handRed = Color(0xFFE53935); // Red for hand finger tip
  static const Color handOrange =
      Color(0xFFFF6B35); // Orange for hand finger tip
}
