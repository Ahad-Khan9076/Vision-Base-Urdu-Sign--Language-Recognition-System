/// App size constants for consistent spacing and dimensions
class AppSizes {
  AppSizes._();

  // Spacing
  static const double spacingXS = 4.0;
  static const double spacingS = 8.0;
  static const double spacingM = 16.0;
  static const double spacingL = 24.0;
  static const double spacingXL = 32.0;
  static const double spacingXXL = 48.0;

  // Border Radius
  static const double radiusS = 8.0;
  static const double radiusM = 12.0;
  static const double radiusL = 16.0;
  static const double radiusXL = 24.0;
  static const double radiusCircular = 999.0;

  // Icon Sizes
  static const double iconXS = 16.0;
  static const double iconS = 20.0;
  static const double iconM = 24.0;
  static const double iconL = 32.0;
  static const double iconXL = 48.0;

  // Button Heights
  static const double buttonHeightS = 36.0;
  static const double buttonHeightM = 48.0;
  static const double buttonHeightL = 56.0;

  // Card Dimensions
  static const double cardElevation = 2.0;
  static const double cardBorderRadius = 12.0;

  // App Bar
  static const double appBarHeight = 56.0;

  // Bottom Navigation
  static const double bottomNavHeight = 64.0;

  // Image Sizes
  static const double imageThumbnail = 80.0;
  static const double imageSmall = 120.0;
  static const double imageMedium = 200.0;
  static const double imageLarge = 300.0;

  // Animation Durations (milliseconds)
  static const int animationDurationShort = 200;
  static const int animationDurationMedium = 300;
  static const int animationDurationLong = 500;
}

