import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../features/splash/presentation/splash_screen.dart';
import '../../features/auth/presentation/role_selection_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/user_login_screen.dart';
import '../../features/auth/presentation/user_signup_screen.dart';
import '../../features/auth/presentation/forgot_password_screen.dart';
import '../../features/home/presentation/home_screen.dart';
import '../../features/user_home/presentation/user_home_screen.dart';
import '../../features/user_management/presentation/user_management_screen.dart';
import '../../features/analytics/presentation/analytics_screen.dart';
import '../../features/sign_detection/presentation/camera_recognition_screen.dart';
import '../../features/profile/presentation/profile_screen.dart';
import '../constants/app_routes.dart';

// TODO: Import other screens as they are implemented
// import '../../features/onboarding/presentation/onboarding_screen.dart';
// import '../../features/auth/presentation/signup_screen.dart';
// import '../../features/sign_detection/presentation/sign_to_text_screen.dart';
// import '../../features/sign_detection/presentation/text_to_sign_screen.dart';
// import '../../features/learning/presentation/learning_screen.dart';
// import '../../features/learning/presentation/learning_category_screen.dart';
// import '../../features/learning/presentation/learning_detail_screen.dart';
// import '../../features/practice/presentation/practice_screen.dart';
// import '../../features/practice/presentation/quiz_screen.dart';
// import '../../features/profile/presentation/profile_screen.dart';
// import '../../features/profile/presentation/settings_screen.dart';
// import '../../features/profile/presentation/progress_history_screen.dart';

/// App router configuration using go_router
class AppRouter {
  AppRouter._();

  static final GoRouter router = GoRouter(
    initialLocation: AppRoutes.splash,
    routes: [
      // Splash
      GoRoute(
        path: AppRoutes.splash,
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),

      // Role Selection
      GoRoute(
        path: AppRoutes.roleSelection,
        name: 'roleSelection',
        builder: (context, state) => const RoleSelectionScreen(),
      ),

      // Authentication
      GoRoute(
        path: AppRoutes.login,
        name: 'login',
        builder: (context, state) => const LoginScreen(), // Admin login
      ),
      GoRoute(
        path: AppRoutes.userLogin,
        name: 'userLogin',
        builder: (context, state) => const UserLoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.signUp,
        name: 'signUp',
        builder: (context, state) => const UserSignUpScreen(),
      ),
      GoRoute(
        path: AppRoutes.forgotPassword,
        name: 'forgotPassword',
        builder: (context, state) => const ForgotPasswordScreen(),
      ),

      // Main App
      GoRoute(
        path: AppRoutes.home,
        name: 'home',
        builder: (context, state) => const HomeScreen(),
      ),
      GoRoute(
        path: AppRoutes.userHome,
        name: 'userHome',
        builder: (context, state) => const UserHomeScreen(),
      ),

      // Admin Screens
      GoRoute(
        path: AppRoutes.userManagement,
        name: 'userManagement',
        builder: (context, state) => const UserManagementScreen(),
      ),
      GoRoute(
        path: AppRoutes.analytics,
        name: 'analytics',
        builder: (context, state) => const AnalyticsScreen(),
      ),

      // Sign Detection
      GoRoute(
        path: AppRoutes.signToText,
        name: 'signToText',
        builder: (context, state) => const CameraRecognitionScreen(),
      ),

      // Profile
      GoRoute(
        path: AppRoutes.profile,
        name: 'profile',
        builder: (context, state) => const ProfileScreen(),
      ),

      // TODO: Add other routes as screens are implemented
      // Onboarding
      // Sign Up
      // Sign Detection
      // Learning
      // Practice
      // Profile
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Text('Error: ${state.error}'),
      ),
    ),
  );
}
