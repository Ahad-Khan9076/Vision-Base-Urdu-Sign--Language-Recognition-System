import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Base ViewModel class following MVVM pattern
abstract class BaseViewModel extends StateNotifier<ViewModelState> {
  BaseViewModel() : super(const InitialState());

  /// Handle loading state
  void setLoading() {
    state = const LoadingState();
  }

  /// Handle success state
  void setSuccess([dynamic data]) {
    state = SuccessState(data);
  }

  /// Handle error state
  void setError(String message) {
    state = ErrorState(message);
  }

  /// Reset to initial state
  void reset() {
    state = const InitialState();
  }
}

/// ViewModel state sealed class
sealed class ViewModelState {
  const ViewModelState();
}

class InitialState extends ViewModelState {
  const InitialState();
}

class LoadingState extends ViewModelState {
  const LoadingState();
}

class SuccessState extends ViewModelState {
  const SuccessState([this.data]);

  final dynamic data;
}

class ErrorState extends ViewModelState {
  const ErrorState(this.message);

  final String message;
}

