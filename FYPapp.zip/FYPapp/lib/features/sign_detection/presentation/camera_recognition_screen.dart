import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:camera/camera.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';

/// Camera Recognition Screen for sign language recognition
class CameraRecognitionScreen extends StatefulWidget {
  const CameraRecognitionScreen({super.key});

  @override
  State<CameraRecognitionScreen> createState() =>
      _CameraRecognitionScreenState();
}

class _CameraRecognitionScreenState extends State<CameraRecognitionScreen> {
  bool _isRecognitionActive = false;
  String _recognitionResult = '';
  CameraController? _cameraController;
  bool _isCameraInitialized = false;

  @override
  void initState() {
    super.initState();
    // Don't initialize camera on screen load - wait for user to click Start Recognition
  }

  @override
  void dispose() {
    _cameraController?.dispose();
    super.dispose();
  }

  Future<void> _initializeCamera() async {
    // Request camera permission
    final status = await Permission.camera.request();
    if (status.isGranted) {
      // Get available cameras
      final cameras = await availableCameras();
      if (cameras.isNotEmpty) {
        // Use front camera if available, otherwise use back camera
        final camera = cameras.firstWhere(
          (camera) => camera.lensDirection == CameraLensDirection.front,
          orElse: () => cameras.first,
        );

        _cameraController = CameraController(
          camera,
          ResolutionPreset.high,
          enableAudio: false,
        );

        try {
          await _cameraController!.initialize();
          if (mounted) {
            setState(() => _isCameraInitialized = true);
          }
        } catch (e) {
          if (mounted) {
            setState(() {
              _isCameraInitialized = false;
              _isRecognitionActive = false;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Failed to initialize camera: $e')),
            );
          }
        }
      }
    } else {
      setState(() {
        _isRecognitionActive = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Camera permission is required to use this feature'),
            duration: Duration(seconds: 3),
          ),
        );
      }
    }
  }

  Future<void> _startRecognition() async {
    if (!_isCameraInitialized) {
      // Initialize camera first
      await _initializeCamera();
    }

    if (_isCameraInitialized) {
      setState(() {
        _isRecognitionActive = true;
      });
      // TODO: Start actual sign language recognition
    }
  }

  Future<void> _stopRecognition() async {
    setState(() {
      _isRecognitionActive = false;
      // Simulate recognition result - in real app, this would come from ML model
      // For demo purposes, showing a sample recognized sign
      final sampleResults = [
        'Hello',
        'Thank you',
        'Please',
        'Yes',
        'No',
        'How are you?',
        'Good morning',
        'Nice to meet you',
      ];
      _recognitionResult =
          sampleResults[DateTime.now().millisecond % sampleResults.length];
    });

    // Dispose camera when stopping recognition
    await _cameraController?.dispose();
    setState(() {
      _isCameraInitialized = false;
      _cameraController = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppSizes.spacingL),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header with Back Button and Title
                Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () {
                        if (context.canPop()) {
                          context.pop();
                        } else {
                          context.go(AppRoutes.userHome);
                        }
                      },
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          'Camera Recognition',
                          style: Theme.of(context)
                              .textTheme
                              .headlineSmall
                              ?.copyWith(
                                color: AppColors.darkBlue,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                      ),
                    ),
                    // Invisible icon to balance the back button
                    const SizedBox(width: 48),
                  ],
                ),
                const SizedBox(height: AppSizes.spacingXL),
                // Camera View
                Container(
                  width: double.infinity,
                  height: 300,
                  decoration: BoxDecoration(
                    color: AppColors.darkBlue,
                    borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    child: _isCameraInitialized &&
                            _cameraController != null &&
                            _cameraController!.value.isInitialized
                        ? AspectRatio(
                            aspectRatio: _cameraController!.value.aspectRatio,
                            child: CameraPreview(_cameraController!),
                          )
                        : Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.camera_alt_outlined,
                                  color: Colors.white.withOpacity(0.7),
                                  size: 80,
                                ),
                                const SizedBox(height: AppSizes.spacingM),
                                Text(
                                  _isRecognitionActive
                                      ? 'Initializing camera...'
                                      : 'Camera is off\nClick "Start Recognition" to begin',
                                  style: TextStyle(
                                    color: Colors.white.withOpacity(0.9),
                                    fontSize: 14,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                          ),
                  ),
                ),
                const SizedBox(height: AppSizes.spacingXL),
                // Start/Stop Recognition Button
                SizedBox(
                  width: double.infinity,
                  height: AppSizes.buttonHeightL + 25,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      if (_isRecognitionActive) {
                        await _stopRecognition();
                      } else {
                        await _startRecognition();
                      }
                    },
                    icon: Icon(
                      _isRecognitionActive ? Icons.stop : Icons.camera_alt,
                      color: Colors.white,
                      size: 24,
                    ),
                    label: Flexible(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            _isRecognitionActive
                                ? 'Stop Recognition'
                                : 'Start Recognition',
                            style: Theme.of(context)
                                .textTheme
                                .titleLarge
                                ?.copyWith(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            _isRecognitionActive
                                ? 'شناخت روکیں'
                                : 'شناخت شروع کریں',
                            style:
                                Theme.of(context).textTheme.bodySmall?.copyWith(
                                      color: Colors.white,
                                      fontSize: 12,
                                    ),
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _isRecognitionActive
                          ? Colors.red
                          : AppColors.darkBlue,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                      ),
                      elevation: 0,
                    ),
                  ),
                ),
                const SizedBox(height: AppSizes.spacingXL),
                // Recognition Result Section
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(AppSizes.spacingL),
                  decoration: BoxDecoration(
                    color: AppColors.darkBlue,
                    borderRadius: BorderRadius.circular(AppSizes.radiusL),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Text(
                        'Recognition Result',
                        style:
                            Theme.of(context).textTheme.titleMedium?.copyWith(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                      ),
                      const SizedBox(height: AppSizes.spacingM),
                      // Result Display Area
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppSizes.spacingM,
                          vertical: AppSizes.spacingL,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        ),
                        child: Row(
                          children: [
                            // Speaker Icon
                            Icon(
                              Icons.volume_up,
                              color: AppColors.darkBlue,
                              size: 28,
                            ),
                            const SizedBox(width: AppSizes.spacingM),
                            // Recognition Result Text
                            Expanded(
                              child: Text(
                                _recognitionResult.isEmpty
                                    ? 'Recognition result will appear here...'
                                    : _recognitionResult,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyLarge
                                    ?.copyWith(
                                      color: _recognitionResult.isEmpty
                                          ? Colors.grey[600]
                                          : Colors.black,
                                      fontSize: 16,
                                    ),
                              ),
                            ),
                            // Play Audio Button (if result exists)
                            if (_recognitionResult.isNotEmpty)
                              IconButton(
                                icon: Icon(
                                  Icons.play_circle_outline,
                                  color: AppColors.darkBlue,
                                  size: 32,
                                ),
                                onPressed: () {
                                  // TODO: Play audio for recognized sign
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Playing audio...'),
                                      duration: Duration(seconds: 1),
                                    ),
                                  );
                                },
                              ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSizes.spacingXL),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
