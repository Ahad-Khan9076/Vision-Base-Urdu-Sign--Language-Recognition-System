import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/base/base_viewmodel.dart';

/// Dashboard data models
class KPIData {
  final String title;
  final String value;
  final String growth;
  final bool isPositive;

  const KPIData({
    required this.title,
    required this.value,
    required this.growth,
    this.isPositive = true,
  });
}

class ActivityData {
  final String month;
  final double thisYear;
  final double lastYear;

  const ActivityData({
    required this.month,
    required this.thisYear,
    required this.lastYear,
  });
}

class SignUsageData {
  final String sign;
  final double count;
  final Color color;

  const SignUsageData({
    required this.sign,
    required this.count,
    required this.color,
  });
}

class RecentActivity {
  final String date;
  final String activeUsers;
  final String signsPerformed;
  final String avgPerUser;

  const RecentActivity({
    required this.date,
    required this.activeUsers,
    required this.signsPerformed,
    required this.avgPerUser,
  });
}

/// Dashboard ViewModel
class DashboardViewModel extends BaseViewModel {
  DashboardViewModel() : super();

  List<KPIData> get kpiData => [
        const KPIData(
          title: 'Total Users',
          value: '248',
          growth: '+12.5%',
        ),
        const KPIData(
          title: 'Active Users',
          value: '189',
          growth: '+6.3%',
        ),
        const KPIData(
          title: 'Total Signs',
          value: '29,342',
          growth: '+15.03%',
        ),
        const KPIData(
          title: 'Avg Signs/User',
          value: '118.3',
          growth: '+5.7%',
        ),
      ];

  List<ActivityData> get activityData => [
        const ActivityData(month: 'Jan', thisYear: 10000, lastYear: 8000),
        const ActivityData(month: 'Feb', thisYear: 15000, lastYear: 12000),
        const ActivityData(month: 'Mar', thisYear: 20000, lastYear: 18000),
      ];

  List<SignUsageData> get signUsageData => [
        const SignUsageData(sign: 'Please', count: 4500, color: Color(0xFF64B5F6)), // Light blue
        const SignUsageData(sign: 'Hello', count: 3800, color: Color(0xFF4DB6AC)), // Teal
        const SignUsageData(sign: 'Help', count: 3200, color: Color(0xFF424242)), // Black/Dark gray
        const SignUsageData(sign: 'Thank You', count: 2800, color: Color(0xFF2196F3)), // Blue
        const SignUsageData(sign: 'I am sick', count: 2200, color: Color(0xFF9C27B0)), // Purple
        const SignUsageData(sign: 'How?', count: 1800, color: Color(0xFF4DB6AC)), // Teal
      ];

  List<RecentActivity> get recentActivity => [
        const RecentActivity(
          date: 'Thu, Dec 19',
          activeUsers: '223',
          signsPerformed: '5,234',
          avgPerUser: '23',
        ),
        const RecentActivity(
          date: 'Wed, Dec 18',
          activeUsers: '156',
          signsPerformed: '3,654',
          avgPerUser: '23',
        ),
        const RecentActivity(
          date: 'Tue, Dec 17',
          activeUsers: '178',
          signsPerformed: '4,123',
          avgPerUser: '23',
        ),
      ];

  Future<void> loadDashboardData() async {
    setLoading();
    try {
      // TODO: Fetch actual data from API
      await Future.delayed(const Duration(seconds: 1));
      setSuccess();
    } catch (e) {
      setError(e.toString());
    }
  }
}

/// Dashboard ViewModel Provider
final dashboardViewModelProvider =
    StateNotifierProvider<DashboardViewModel, ViewModelState>((ref) {
  return DashboardViewModel();
});

