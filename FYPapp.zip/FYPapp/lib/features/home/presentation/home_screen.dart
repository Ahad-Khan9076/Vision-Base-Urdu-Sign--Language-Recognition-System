import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';
import 'viewmodels/dashboard_viewmodel.dart';
import 'widgets/kpi_card.dart';
import 'widgets/activity_trend_chart.dart';
import 'widgets/sign_usage_chart.dart';
import 'widgets/info_card.dart';
import 'widgets/recent_activity_table.dart';
import 'widgets/admin_navigation_drawer.dart';

/// Admin Dashboard Screen
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(dashboardViewModelProvider.notifier).loadDashboardData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(dashboardViewModelProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      drawer: const AdminNavigationDrawer(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Logo and Title Section
              _buildHeader(context),
              const SizedBox(height: AppSizes.spacingL),
              // KPI Cards Grid
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                child: _buildKPIGrid(context, viewModel),
              ),
              const SizedBox(height: AppSizes.spacingL),
              // Charts Section
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                child: Column(
                  children: [
                    // User Activity Trend Chart
                    ActivityTrendChart(data: viewModel.activityData),
                    const SizedBox(height: AppSizes.spacingL),
                    // Most Used Signs Chart
                    SignUsageChart(data: viewModel.signUsageData),
                    const SizedBox(height: AppSizes.spacingL),
                  ],
                ),
              ),
              // Info Cards Section
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                child: Column(
                  children: [
                    InfoCard(
                      title: 'Most Active Day',
                      value: 'Friday',
                      subtitle: 'Highest user engagement this week',
                    ),
                    const SizedBox(height: AppSizes.spacingM),
                    InfoCard(
                      title: 'Peak Usage Hour',
                      value: '14:00 - 15:00',
                      subtitle: 'Busiest time for sign recognition',
                    ),
                    const SizedBox(height: AppSizes.spacingM),
                    InfoCard(
                      title: 'System Status',
                      value: '99.9%',
                      subtitle: 'Uptime - All systems operational',
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppSizes.spacingL),
              // Recent Activity Table Section
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                child: RecentActivityTable(data: viewModel.recentActivity),
              ),
              const SizedBox(height: AppSizes.spacingXL),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              // Hamburger Menu
              Builder(
                builder: (context) => IconButton(
                  icon: const Icon(Icons.menu, color: AppColors.darkBlue),
                  onPressed: () {
                    Scaffold.of(context).openDrawer();
                  },
                ),
              ),
              // Logo and USL
              Row(
                children: [
                  Image.asset(
                    'assets/images/Asset 2 2.png',
                    width: 40,
                    height: 40,
                    fit: BoxFit.contain,
                  ),
                  const SizedBox(width: AppSizes.spacingS),
                  Text(
                    'USL',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: AppColors.orange,
                          fontWeight: FontWeight.bold,
                          fontSize: 24,
                        ),
                  ),
                ],
              ),
              // Refresh/Logout Icon
              IconButton(
                icon: const Icon(Icons.refresh, color: AppColors.darkBlue),
                onPressed: () {
                  ref
                      .read(dashboardViewModelProvider.notifier)
                      .loadDashboardData();
                },
              ),
            ],
          ),
          const SizedBox(height: AppSizes.spacingS),
          Text(
            'Admin Portal',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppColors.darkBlue,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
          ),
          const SizedBox(height: AppSizes.spacingXS),
          Text(
            'Sign Language Recognition System',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppColors.lightBlueText,
                  fontSize: 14,
                ),
          ),
        ],
      ),
    );
  }

  Widget _buildKPIGrid(BuildContext context, DashboardViewModel viewModel) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: AppSizes.spacingM,
        mainAxisSpacing: AppSizes.spacingM,
        childAspectRatio: 1.2,
      ),
      itemCount: viewModel.kpiData.length,
      itemBuilder: (context, index) {
        return KPICard(data: viewModel.kpiData[index]);
      },
    );
  }
}
