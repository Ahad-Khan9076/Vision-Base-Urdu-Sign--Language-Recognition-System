import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';

/// Admin Navigation Drawer
class AdminNavigationDrawer extends StatelessWidget {
  const AdminNavigationDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.white,
      width: MediaQuery.of(context).size.width * 0.7,
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: AppSizes.spacingM),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header Section with Profile
                  _buildHeader(context),
                  const SizedBox(height: AppSizes.spacingS),
                  // Navigation Buttons
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: AppSizes.spacingM),
                    child: _buildNavigationButtons(context),
                  ),
                ],
              ),
            ),
            const Spacer(),
            // Logout Button at Bottom
            Padding(
              padding: const EdgeInsets.all(AppSizes.spacingM),
              child: _buildLogoutButton(context),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Profile Picture
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              image: const DecorationImage(
                image: AssetImage('assets/images/User image.png'),
                fit: BoxFit.cover,
              ),
              border: Border.all(
                color: AppColors.handBlue,
                width: 2,
              ),
            ),
          ),
          const SizedBox(height: AppSizes.spacingXS),
          // Admin Text
          Text(
            'Admin',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildNavigationButtons(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _buildNavButton(
          context,
          icon: Icons.shield,
          label: 'Dashboard',
          onTap: () {
            Navigator.of(context).pop(); // Close drawer first
            Future.microtask(() {
              context.go(AppRoutes.home);
            });
          },
        ),
        const SizedBox(height: AppSizes.spacingM),
        _buildNavButton(
          context,
          icon: Icons.people,
          label: 'User Management',
          onTap: () {
            Navigator.of(context).pop(); // Close drawer first
            Future.microtask(() {
              context.go(AppRoutes.userManagement);
            });
          },
        ),
        const SizedBox(height: AppSizes.spacingM),
        _buildNavButton(
          context,
          icon: Icons.bar_chart,
          label: 'Analytics',
          onTap: () {
            Navigator.of(context).pop(); // Close drawer first
            Future.microtask(() {
              context.go(AppRoutes.analytics);
            });
          },
        ),
      ],
    );
  }

  Widget _buildNavButton(
    BuildContext context, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppSizes.radiusM),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSizes.spacingM,
          vertical: AppSizes.spacingXS + 2,
        ),
        decoration: BoxDecoration(
          color: AppColors.handBlue,
          borderRadius: BorderRadius.circular(AppSizes.radiusM),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: AppSizes.iconM,
            ),
            const SizedBox(width: AppSizes.spacingM),
            Expanded(
              child: Text(
                label,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.of(context).pop(); // Close drawer first
        Future.microtask(() {
          context.go(AppRoutes.login);
        });
      },
      borderRadius: BorderRadius.circular(AppSizes.radiusM),
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSizes.spacingM,
          vertical: AppSizes.spacingS,
        ),
        decoration: BoxDecoration(
          color: Colors.red[400],
          borderRadius: BorderRadius.circular(AppSizes.radiusM),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.logout,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: AppSizes.spacingS),
            Text(
              'Logout',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}
