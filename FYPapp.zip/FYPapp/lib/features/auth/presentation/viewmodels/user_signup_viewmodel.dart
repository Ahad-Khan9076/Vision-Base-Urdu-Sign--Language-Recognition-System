import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/base/base_viewmodel.dart';
import '../../../../core/utils/validators.dart';

/// User Sign Up ViewModel following MVVM pattern
class UserSignUpViewModel extends BaseViewModel {
  UserSignUpViewModel() : super();

  String _firstName = '';
  String _lastName = '';
  String _email = '';
  String _password = '';
  String _confirmPassword = '';
  bool _isPasswordVisible = false;
  bool _isConfirmPasswordVisible = false;
  String? _firstNameError;
  String? _lastNameError;
  String? _emailError;
  String? _passwordError;
  String? _confirmPasswordError;

  String get firstName => _firstName;
  String get lastName => _lastName;
  String get email => _email;
  String get password => _password;
  String get confirmPassword => _confirmPassword;
  bool get isPasswordVisible => _isPasswordVisible;
  bool get isConfirmPasswordVisible => _isConfirmPasswordVisible;
  String? get firstNameError => _firstNameError;
  String? get lastNameError => _lastNameError;
  String? get emailError => _emailError;
  String? get passwordError => _passwordError;
  String? get confirmPasswordError => _confirmPasswordError;

  bool get isFormValid =>
      _firstName.isNotEmpty &&
      _lastName.isNotEmpty &&
      _email.isNotEmpty &&
      _password.isNotEmpty &&
      _confirmPassword.isNotEmpty &&
      _firstNameError == null &&
      _lastNameError == null &&
      _emailError == null &&
      _passwordError == null &&
      _confirmPasswordError == null;

  void updateFirstName(String value) {
    _firstName = value;
    _firstNameError = value.isEmpty ? 'First name is required' : null;
    state = SuccessState({'firstName': _firstName, 'firstNameError': _firstNameError});
  }

  void updateLastName(String value) {
    _lastName = value;
    _lastNameError = value.isEmpty ? 'Last name is required' : null;
    state = SuccessState({'lastName': _lastName, 'lastNameError': _lastNameError});
  }

  void updateEmail(String value) {
    _email = value;
    _emailError = Validators.email(value);
    state = SuccessState({'email': _email, 'emailError': _emailError});
  }

  void updatePassword(String value) {
    _password = value;
    _passwordError = Validators.password(value);
    // Re-validate confirm password if it's already filled
    if (_confirmPassword.isNotEmpty) {
      _confirmPasswordError = _password != _confirmPassword ? 'Passwords do not match' : null;
    }
    state = SuccessState({
      'password': _password,
      'passwordError': _passwordError,
      'confirmPasswordError': _confirmPasswordError,
    });
  }

  void updateConfirmPassword(String value) {
    _confirmPassword = value;
    _confirmPasswordError = _password != value ? 'Passwords do not match' : null;
    state = SuccessState({'confirmPassword': _confirmPassword, 'confirmPasswordError': _confirmPasswordError});
  }

  void togglePasswordVisibility() {
    _isPasswordVisible = !_isPasswordVisible;
    state = SuccessState({'isPasswordVisible': _isPasswordVisible});
  }

  void toggleConfirmPasswordVisibility() {
    _isConfirmPasswordVisible = !_isConfirmPasswordVisible;
    state = SuccessState({'isConfirmPasswordVisible': _isConfirmPasswordVisible});
  }

  Future<void> signUp() async {
    // Validate form
    _firstNameError = _firstName.isEmpty ? 'First name is required' : null;
    _lastNameError = _lastName.isEmpty ? 'Last name is required' : null;
    _emailError = Validators.email(_email);
    _passwordError = Validators.password(_password);
    _confirmPasswordError = _password != _confirmPassword ? 'Passwords do not match' : null;

    if (_firstNameError != null ||
        _lastNameError != null ||
        _emailError != null ||
        _passwordError != null ||
        _confirmPasswordError != null) {
      state = SuccessState({
        'firstNameError': _firstNameError,
        'lastNameError': _lastNameError,
        'emailError': _emailError,
        'passwordError': _passwordError,
        'confirmPasswordError': _confirmPasswordError,
      });
      return;
    }

    setLoading();

    try {
      // TODO: Implement actual sign up logic
      await Future.delayed(const Duration(seconds: 1));

      // Simulate successful sign up
      setSuccess({'message': 'Sign up successful'});
    } catch (e) {
      setError(e.toString());
    }
  }
}

/// User Sign Up ViewModel Provider
final userSignUpViewModelProvider = StateNotifierProvider<UserSignUpViewModel, ViewModelState>((ref) {
  return UserSignUpViewModel();
});
