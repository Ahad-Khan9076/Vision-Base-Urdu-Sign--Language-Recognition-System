import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/base/base_viewmodel.dart';
import '../../../../core/utils/validators.dart';

/// User Login ViewModel following MVVM pattern
class UserLoginViewModel extends BaseViewModel {
  UserLoginViewModel() : super();

  String _email = '';
  String _password = '';
  bool _isPasswordVisible = false;
  String? _emailError;
  String? _passwordError;

  String get email => _email;
  String get password => _password;
  bool get isPasswordVisible => _isPasswordVisible;
  String? get emailError => _emailError;
  String? get passwordError => _passwordError;

  bool get isFormValid => _email.isNotEmpty && _password.isNotEmpty && _emailError == null && _passwordError == null;

  void updateEmail(String value) {
    _email = value;
    _emailError = Validators.email(value);
    state = SuccessState({'email': _email, 'emailError': _emailError});
  }

  void updatePassword(String value) {
    _password = value;
    _passwordError = Validators.password(value);
    state = SuccessState({'password': _password, 'passwordError': _passwordError});
  }

  void togglePasswordVisibility() {
    _isPasswordVisible = !_isPasswordVisible;
    state = SuccessState({'isPasswordVisible': _isPasswordVisible});
  }

  Future<void> login() async {
    // Validate form
    _emailError = Validators.email(_email);
    _passwordError = Validators.password(_password);

    if (_emailError != null || _passwordError != null) {
      state = SuccessState({
        'emailError': _emailError,
        'passwordError': _passwordError,
      });
      return;
    }

    setLoading();

    try {
      // TODO: Implement actual login logic
      await Future.delayed(const Duration(seconds: 1));

      // Simulate successful login
      setSuccess({'message': 'Login successful'});
    } catch (e) {
      setError(e.toString());
    }
  }
}

/// User Login ViewModel Provider
final userLoginViewModelProvider = StateNotifierProvider<UserLoginViewModel, ViewModelState>((ref) {
  return UserLoginViewModel();
});
