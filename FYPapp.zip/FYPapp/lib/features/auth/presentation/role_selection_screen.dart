import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';

/// Role Selection Screen - Choose between User and Admin
class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(AppSizes.spacingXL),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(height: AppSizes.spacingXXL),
                // Logo
                Image.asset(
                  'assets/images/Asset 2 2.png',
                  width: 120,
                  height: 120,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: AppSizes.spacingXL),
                // Title
                Text(
                  'Welcome to USL',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: AppColors.darkBlue,
                        fontWeight: FontWeight.bold,
                        fontSize: 28,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSizes.spacingS),
                Text(
                  'Sign Language Recognition System',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.lightBlueText,
                        fontSize: 14,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: AppSizes.spacingXXL * 2),
                // Role Selection Text
                Text(
                  'Select Your Role',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: AppColors.darkBlue,
                        fontWeight: FontWeight.w600,
                        fontSize: 20,
                      ),
                ),
                const SizedBox(height: AppSizes.spacingXL),
                // User Role Button
                _buildRoleButton(
                  context,
                  icon: Icons.person,
                  title: 'User',
                  subtitle: 'Sign in or create an account',
                  color: AppColors.handBlue,
                  onTap: () {
                    context.go(AppRoutes.userLogin);
                  },
                ),
                const SizedBox(height: AppSizes.spacingL),
                // Admin Role Button
                _buildRoleButton(
                  context,
                  icon: Icons.shield,
                  title: 'Admin',
                  subtitle: 'Access admin panel',
                  color: AppColors.orange,
                  onTap: () {
                    context.go(AppRoutes.login);
                  },
                ),
                const SizedBox(height: AppSizes.spacingXXL),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoleButton(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppSizes.radiusL),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(AppSizes.spacingL),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(AppSizes.radiusL),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
          border: Border.all(
            color: color.withOpacity(0.3),
            width: 2,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(AppSizes.spacingM),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(AppSizes.radiusM),
              ),
              child: Icon(
                icon,
                color: color,
                size: 40,
              ),
            ),
            const SizedBox(width: AppSizes.spacingL),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: color,
                          fontWeight: FontWeight.bold,
                          fontSize: 22,
                        ),
                  ),
                  const SizedBox(height: AppSizes.spacingXS),
                  Text(
                    subtitle,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey[600],
                          fontSize: 13,
                        ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: color,
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}

