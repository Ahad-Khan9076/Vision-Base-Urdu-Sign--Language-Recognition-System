import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/base/base_viewmodel.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';
import 'viewmodels/login_viewmodel.dart';

/// Login screen for admin portal
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});

  @override
  ConsumerState<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends ConsumerState<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _handleLogin() {
    final viewModel = ref.read(loginViewModelProvider.notifier);
    viewModel.login();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(loginViewModelProvider.notifier);
    final viewModelState = ref.watch(loginViewModelProvider);

    // Listen to state changes
    ref.listen<ViewModelState>(loginViewModelProvider, (previous, next) {
      if (next is SuccessState && next.data != null) {
        // Check if it's a successful login (not just form update)
        if (next.data is Map && next.data['message'] == 'Login successful') {
          context.go(AppRoutes.home);
        }
      } else if (next is ErrorState) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(next.message)),
        );
      }
    });

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingL),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: AppSizes.spacingM),
                  // Back Button
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: AppColors.darkBlue),
                    onPressed: () {
                      if (context.canPop()) {
                        context.pop();
                      } else {
                        context.go(AppRoutes.roleSelection);
                      }
                    },
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                  // Welcome Text - Centered
                  Center(
                    child: Column(
                      children: [
                        Text(
                          'Welcome to',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                color: AppColors.darkBlue,
                                fontSize: 24,
                              ),
                        ),
                        const SizedBox(height: AppSizes.spacingXS),
                        // USL Text
                        Text(
                          'USL',
                          style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                                color: AppColors.orange,
                                fontWeight: FontWeight.bold,
                                fontSize: 32,
                              ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                  // Logo Image
                  Center(
                    child: Image.asset(
                      'assets/images/Asset 2 2.png',
                      width: 120,
                      height: 120,
                      fit: BoxFit.contain,
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingL),
                  // Admin Portal Text
                  Center(
                    child: Text(
                      'Admin Portal',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: AppColors.darkBlue,
                            fontSize: 18,
                          ),
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingXXL),
                  // Email Field
                  Text(
                    'Email',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                  ),
                  const SizedBox(height: AppSizes.spacingS),
                  TextFormField(
                    controller: _emailController,
                    keyboardType: TextInputType.emailAddress,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintText: 'Enter your email',
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: BorderSide.none,
                      ),
                      errorText: viewModel.emailError,
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: const BorderSide(color: AppColors.error),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: const BorderSide(color: AppColors.error, width: 2),
                      ),
                    ),
                    onChanged: (value) => viewModel.updateEmail(value),
                    validator: (value) => viewModel.emailError,
                  ),
                  const SizedBox(height: AppSizes.spacingL),
                  // Password Field
                  Text(
                    'Password',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                  ),
                  const SizedBox(height: AppSizes.spacingS),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: !viewModel.isPasswordVisible,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                      hintText: 'Enter your password',
                      filled: true,
                      fillColor: Colors.grey[100],
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: BorderSide.none,
                      ),
                      suffixIcon: IconButton(
                        icon: Icon(
                          viewModel.isPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.grey[600],
                        ),
                        onPressed: () => viewModel.togglePasswordVisibility(),
                      ),
                      errorText: viewModel.passwordError,
                      errorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: const BorderSide(color: AppColors.error),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        borderSide: const BorderSide(color: AppColors.error, width: 2),
                      ),
                    ),
                    onChanged: (value) => viewModel.updatePassword(value),
                    onFieldSubmitted: (_) => _handleLogin(),
                    validator: (value) => viewModel.passwordError,
                  ),
                  const SizedBox(height: AppSizes.spacingXXL),
                  // Login Button
                  SizedBox(
                    width: double.infinity,
                    height: AppSizes.buttonHeightL,
                    child: ElevatedButton(
                      onPressed: viewModelState is LoadingState ? null : _handleLogin,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.lightBlue,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(AppSizes.radiusM),
                        ),
                        elevation: 0,
                      ),
                      child: viewModelState is LoadingState
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            )
                          : Text(
                              'Login to Dashboard',
                              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

