import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/base/base_viewmodel.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';
import 'viewmodels/user_login_viewmodel.dart';
import 'widgets/success_popup.dart';

/// User Login Screen
class UserLoginScreen extends ConsumerStatefulWidget {
  const UserLoginScreen({super.key});

  @override
  ConsumerState<UserLoginScreen> createState() => _UserLoginScreenState();
}

class _UserLoginScreenState extends ConsumerState<UserLoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _handleLogin() {
    final viewModel = ref.read(userLoginViewModelProvider.notifier);
    viewModel.login();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(userLoginViewModelProvider.notifier);
    final viewModelState = ref.watch(userLoginViewModelProvider);

    // Listen to state changes
    ref.listen<ViewModelState>(userLoginViewModelProvider, (previous, next) {
      if (next is SuccessState && next.data != null) {
        // Check if it's a successful login (not just form update)
        if (next.data is Map && next.data['message'] == 'Login successful') {
          // Show success popup - store navigation context before showing dialog
          final navigatorContext = context;
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (dialogContext) => const SuccessPopup(
              title: 'Congratulations!',
              message: 'Login Successful!',
            ),
          );
          // Auto-navigate after 2 seconds
          Future.delayed(const Duration(seconds: 2), () {
            if (navigatorContext.mounted) {
              // Close dialog first
              Navigator.of(navigatorContext, rootNavigator: true).pop();
              // Then navigate after dialog is closed
              Future.delayed(const Duration(milliseconds: 150), () {
                if (navigatorContext.mounted) {
                  navigatorContext.go(AppRoutes.userHome);
                }
              });
            }
          });
        }
      } else if (next is ErrorState) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(next.message)),
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingL),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const SizedBox(height: AppSizes.spacingXL),
                  // White Card Container
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSizes.spacingXL),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Back Button
                        IconButton(
                          icon: const Icon(Icons.arrow_back,
                              color: AppColors.darkBlue),
                          onPressed: () {
                            if (context.canPop()) {
                              context.pop();
                            } else {
                              context.go(AppRoutes.roleSelection);
                            }
                          },
                          alignment: Alignment.topLeft,
                          padding: EdgeInsets.zero,
                          constraints: const BoxConstraints(),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        // Welcome Text - Centered
                        Center(
                          child: Column(
                            children: [
                              Text(
                                'Welcome to',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      color: AppColors.darkBlue,
                                      fontSize: 20,
                                    ),
                              ),
                              const SizedBox(height: AppSizes.spacingXS),
                              // USL Text
                              Text(
                                'USL',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineLarge
                                    ?.copyWith(
                                      color: AppColors.orange,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 36,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: AppSizes.spacingXL),
                        // Logo Image - Centered
                        Center(
                          child: Image.asset(
                            'assets/images/Asset 2 2.png',
                            width: 120,
                            height: 120,
                            fit: BoxFit.contain,
                          ),
                        ),
                        const SizedBox(height: AppSizes.spacingXXL),
                        // Email Field
                        Text(
                          'Email',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: 'Enter your email',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            errorText: viewModel.emailError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) => viewModel.updateEmail(value),
                          validator: (value) => viewModel.emailError,
                        ),
                        const SizedBox(height: AppSizes.spacingL),
                        // Password Field
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text(
                                  'Password',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: AppColors.darkBlue,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                      ),
                                ),
                                // Forgot Password Text
                                TextButton(
                                  onPressed: () {
                                    context.go(AppRoutes.forgotPassword);
                                  },
                                  style: TextButton.styleFrom(
                                    padding: EdgeInsets.zero,
                                    minimumSize: Size.zero,
                                    tapTargetSize:
                                        MaterialTapTargetSize.shrinkWrap,
                                  ),
                                  child: Text(
                                    'Forgot password?',
                                    style: Theme.of(context)
                                        .textTheme
                                        .bodySmall
                                        ?.copyWith(
                                          color: Colors.grey[600],
                                          fontSize: 12,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: AppSizes.spacingS),
                            TextFormField(
                              controller: _passwordController,
                              obscureText: !viewModel.isPasswordVisible,
                              textInputAction: TextInputAction.done,
                              decoration: InputDecoration(
                                hintText: 'Enter your password',
                                filled: true,
                                fillColor: Colors.grey[100],
                                border: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.circular(AppSizes.radiusM),
                                  borderSide: BorderSide.none,
                                ),
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: AppSizes.spacingM,
                                  vertical: AppSizes.spacingM,
                                ),
                                suffixIcon: IconButton(
                                  icon: Icon(
                                    viewModel.isPasswordVisible
                                        ? Icons.visibility
                                        : Icons.visibility_off,
                                    color: Colors.grey[600],
                                  ),
                                  onPressed: () =>
                                      viewModel.togglePasswordVisibility(),
                                ),
                                errorText: viewModel.passwordError,
                                errorBorder: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.circular(AppSizes.radiusM),
                                  borderSide:
                                      const BorderSide(color: AppColors.error),
                                ),
                                focusedErrorBorder: OutlineInputBorder(
                                  borderRadius:
                                      BorderRadius.circular(AppSizes.radiusM),
                                  borderSide: const BorderSide(
                                      color: AppColors.error, width: 2),
                                ),
                              ),
                              onChanged: (value) =>
                                  viewModel.updatePassword(value),
                              onFieldSubmitted: (_) => _handleLogin(),
                              validator: (value) => viewModel.passwordError,
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSizes.spacingXXL),
                        // Log in Button
                        SizedBox(
                          width: double.infinity,
                          height: AppSizes.buttonHeightL,
                          child: ElevatedButton(
                            onPressed: viewModelState is LoadingState
                                ? null
                                : _handleLogin,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.darkBlue,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(AppSizes.radiusM),
                              ),
                              elevation: 0,
                            ),
                            child: viewModelState is LoadingState
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          Colors.white),
                                    ),
                                  )
                                : Text(
                                    'Log in',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                        ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: AppSizes.spacingXL),
                        // Sign Up Link
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                "Don't have an account?",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Colors.grey[600],
                                      fontSize: 14,
                                    ),
                              ),
                              const SizedBox(width: AppSizes.spacingXS),
                              TextButton(
                                onPressed: () {
                                  context.go(AppRoutes.signUp);
                                },
                                style: TextButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  minimumSize: Size.zero,
                                  tapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                                child: Text(
                                  'Sign Up',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: AppColors.darkBlue,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
