import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/base/base_viewmodel.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';
import 'viewmodels/user_signup_viewmodel.dart';
import 'widgets/success_popup.dart';

/// User Sign Up Screen
class UserSignUpScreen extends ConsumerStatefulWidget {
  const UserSignUpScreen({super.key});

  @override
  ConsumerState<UserSignUpScreen> createState() => _UserSignUpScreenState();
}

class _UserSignUpScreenState extends ConsumerState<UserSignUpScreen> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  void _handleSignUp() {
    final viewModel = ref.read(userSignUpViewModelProvider.notifier);
    viewModel.signUp();
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(userSignUpViewModelProvider.notifier);
    final viewModelState = ref.watch(userSignUpViewModelProvider);

    // Listen to state changes
    ref.listen<ViewModelState>(userSignUpViewModelProvider, (previous, next) {
      if (next is SuccessState && next.data != null) {
        // Check if it's a successful sign up (not just form update)
        if (next.data is Map && next.data['message'] == 'Sign up successful') {
          // Show success popup - store navigation context before showing dialog
          final navigatorContext = context;
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (dialogContext) => const SuccessPopup(
              title: 'Congratulations!',
              message: 'Account Created Successfully!',
            ),
          );
          // Auto-navigate after 2 seconds
          Future.delayed(const Duration(seconds: 2), () {
            if (navigatorContext.mounted) {
              // Close dialog first
              Navigator.of(navigatorContext, rootNavigator: true).pop();
              // Then navigate after dialog is closed
              Future.delayed(const Duration(milliseconds: 150), () {
                if (navigatorContext.mounted) {
                  navigatorContext.go(AppRoutes.userHome);
                }
              });
            }
          });
        }
      } else if (next is ErrorState) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(next.message)),
        );
      }
    });

    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingL),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const SizedBox(height: AppSizes.spacingXL),
                  // White Card Container
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(AppSizes.spacingXL),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(AppSizes.radiusL),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Header with Back Button and Title
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.arrow_back,
                                  color: AppColors.darkBlue),
                              onPressed: () {
                                if (context.canPop()) {
                                  context.pop();
                                } else {
                                  context.go(AppRoutes.userLogin);
                                }
                              },
                            ),
                            Expanded(
                              child: Center(
                                child: Text(
                                  'Sign Up',
                                  style: Theme.of(context)
                                      .textTheme
                                      .headlineSmall
                                      ?.copyWith(
                                        color: AppColors.darkBlue,
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                      ),
                                ),
                              ),
                            ),
                            // Invisible icon to balance the back button
                            const SizedBox(width: 48),
                          ],
                        ),
                        const SizedBox(height: AppSizes.spacingXXL),
                        // First Name Field
                        Text(
                          'First name',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _firstNameController,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: 'Enter your first name',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            errorText: viewModel.firstNameError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) =>
                              viewModel.updateFirstName(value),
                          validator: (value) => viewModel.firstNameError,
                        ),
                        const SizedBox(height: AppSizes.spacingL),
                        // Last Name Field
                        Text(
                          'Last Name',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _lastNameController,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: 'Enter your last name',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            errorText: viewModel.lastNameError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) => viewModel.updateLastName(value),
                          validator: (value) => viewModel.lastNameError,
                        ),
                        const SizedBox(height: AppSizes.spacingL),
                        // Email Field
                        Text(
                          'Email',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: 'Enter your email',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            errorText: viewModel.emailError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) => viewModel.updateEmail(value),
                          validator: (value) => viewModel.emailError,
                        ),
                        const SizedBox(height: AppSizes.spacingL),
                        // Password Field
                        Text(
                          'Password',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _passwordController,
                          obscureText: !viewModel.isPasswordVisible,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            hintText: 'Enter your password',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                viewModel.isPasswordVisible
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Colors.grey[600],
                              ),
                              onPressed: () =>
                                  viewModel.togglePasswordVisibility(),
                            ),
                            errorText: viewModel.passwordError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) => viewModel.updatePassword(value),
                          validator: (value) => viewModel.passwordError,
                        ),
                        const SizedBox(height: AppSizes.spacingL),
                        // Confirm Password Field
                        Text(
                          'Confirm password',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: AppColors.darkBlue,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w500,
                                  ),
                        ),
                        const SizedBox(height: AppSizes.spacingS),
                        TextFormField(
                          controller: _confirmPasswordController,
                          obscureText: !viewModel.isConfirmPasswordVisible,
                          textInputAction: TextInputAction.done,
                          decoration: InputDecoration(
                            hintText: 'Confirm your password',
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: AppSizes.spacingM,
                              vertical: AppSizes.spacingM,
                            ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                viewModel.isConfirmPasswordVisible
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                                color: Colors.grey[600],
                              ),
                              onPressed: () =>
                                  viewModel.toggleConfirmPasswordVisibility(),
                            ),
                            errorText: viewModel.confirmPasswordError,
                            errorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide:
                                  const BorderSide(color: AppColors.error),
                            ),
                            focusedErrorBorder: OutlineInputBorder(
                              borderRadius:
                                  BorderRadius.circular(AppSizes.radiusM),
                              borderSide: const BorderSide(
                                  color: AppColors.error, width: 2),
                            ),
                          ),
                          onChanged: (value) =>
                              viewModel.updateConfirmPassword(value),
                          onFieldSubmitted: (_) => _handleSignUp(),
                          validator: (value) => viewModel.confirmPasswordError,
                        ),
                        const SizedBox(height: AppSizes.spacingXXL),
                        // Sign Up Button
                        SizedBox(
                          width: double.infinity,
                          height: AppSizes.buttonHeightL,
                          child: ElevatedButton(
                            onPressed: viewModelState is LoadingState
                                ? null
                                : _handleSignUp,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.darkBlue,
                              foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(AppSizes.radiusM),
                              ),
                              elevation: 0,
                            ),
                            child: viewModelState is LoadingState
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          Colors.white),
                                    ),
                                  )
                                : Text(
                                    'Sign Up',
                                    style: Theme.of(context)
                                        .textTheme
                                        .titleMedium
                                        ?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w500,
                                          fontSize: 16,
                                        ),
                                  ),
                          ),
                        ),
                        const SizedBox(height: AppSizes.spacingXL),
                        // Log In Link
                        Center(
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Already have an account?',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Colors.grey[600],
                                      fontSize: 14,
                                    ),
                              ),
                              const SizedBox(width: AppSizes.spacingXS),
                              TextButton(
                                onPressed: () {
                                  context.go(AppRoutes.userLogin);
                                },
                                style: TextButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  minimumSize: Size.zero,
                                  tapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                ),
                                child: Text(
                                  'Log In',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: AppColors.darkBlue,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
