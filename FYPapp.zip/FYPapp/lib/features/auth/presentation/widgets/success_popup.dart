import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';

/// Success popup shown after successful sign up or login
/// Automatically closes and navigates after 2 seconds
class SuccessPopup extends StatelessWidget {
  final String title;
  final String message;

  const SuccessPopup({
    super.key,
    this.title = 'Congratulations!',
    this.message = 'Account Created Successfully!',
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: Container(
        width: double.infinity,
        height: double.infinity,
        color: AppColors.beigeBackground,
        child: Container(
          width: double.infinity,
          color: Colors.grey[300],
          child: Center(
            child: Container(
              margin: const EdgeInsets.all(AppSizes.spacingXL),
              padding: const EdgeInsets.all(AppSizes.spacingXXL),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(AppSizes.radiusL),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Icon with gold circle, blue shield, and checkmark
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      // Gold circle
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Colors.amber[300],
                          shape: BoxShape.circle,
                        ),
                      ),
                      // Blue shield/pentagon
                      Container(
                        width: 70,
                        height: 70,
                        decoration: BoxDecoration(
                          color: AppColors.darkBlue,
                          shape: BoxShape.circle,
                        ),
                      ),
                      // Checkmark
                      const Icon(
                        Icons.check,
                        color: Colors.white,
                        size: 50,
                        weight: 3,
                      ),
                    ],
                  ),
                  const SizedBox(height: AppSizes.spacingXL),
                  // Congratulations text
                  Text(
                    title,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: AppColors.darkBlue,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: AppSizes.spacingS),
                  // Success message
                  Text(
                    message,
                    style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          color: AppColors.lightBlueText,
                          fontSize: 16,
                        ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
