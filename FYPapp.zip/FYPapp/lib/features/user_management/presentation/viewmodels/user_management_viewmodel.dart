import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/base/base_viewmodel.dart';

/// User model
class User {
  final String id;
  final String fullName;
  final String username;
  final String email;
  final String role;
  final bool isActive;
  final String joinedDate;
  final String lastActive;
  final String? profileImageUrl;

  const User({
    required this.id,
    required this.fullName,
    required this.username,
    required this.email,
    required this.role,
    required this.isActive,
    required this.joinedDate,
    required this.lastActive,
    this.profileImageUrl,
  });
}

/// User Management ViewModel
class UserManagementViewModel extends BaseViewModel {
  UserManagementViewModel() : super();

  String _searchQuery = '';
  String? _selectedRole;
  String? _selectedStatus;
  String? _selectedDate;
  bool _isNameSortAscending = true;
  Set<String> _selectedUserIds = {};

  String get searchQuery => _searchQuery;
  String? get selectedRole => _selectedRole;
  String? get selectedStatus => _selectedStatus;
  String? get selectedDate => _selectedDate;
  bool get isNameSortAscending => _isNameSortAscending;
  Set<String> get selectedUserIds => _selectedUserIds;

  // Mutable list of users
  List<User> _users = [
    const User(
      id: '1',
      fullName: 'Ali Khan',
      username: 'alikhan',
      email: 'ali.khan@gmail.com',
      role: 'Admin',
      isActive: true,
      joinedDate: 'Jan 15, 2024',
      lastActive: '2 hours ago',
    ),
    const User(
      id: '2',
      fullName: 'Ayesha Malik',
      username: 'ayeshamalik',
      email: 'ayeshaMalik@gmail.com',
      role: 'User',
      isActive: true,
      joinedDate: 'Feb 20, 2024',
      lastActive: '5 minutes ago',
    ),
    const User(
      id: '3',
      fullName: 'Hassan Raza',
      username: 'hassanraza',
      email: 'Hassan3@gmail.com',
      role: 'User',
      isActive: true,
      joinedDate: 'Mar 10, 2024',
      lastActive: '1 day ago',
    ),
    const User(
      id: '4',
      fullName: 'Sana Sheikh',
      username: 'sanasheikh',
      email: 'SanaSheikh@gmail.com',
      role: 'Admin',
      isActive: true,
      joinedDate: 'Apr 5, 2024',
      lastActive: '30 minutes ago',
    ),
    const User(
      id: '5',
      fullName: 'Usman Ali',
      username: 'usmanali',
      email: 'Usman777@gmail.com',
      role: 'User',
      isActive: true,
      joinedDate: 'May 12, 2024',
      lastActive: '3 hours ago',
    ),
    const User(
      id: '6',
      fullName: 'Maryam Khan',
      username: 'maryamkhan',
      email: 'MaryamKhan@gmail.com',
      role: 'User',
      isActive: true,
      joinedDate: 'Jun 8, 2024',
      lastActive: '1 hour ago',
    ),
    const User(
      id: '7',
      fullName: 'Imran Qureshi',
      username: 'imranqureshi',
      email: 'imranqureshi@gmail.com',
      role: 'User',
      isActive: true,
      joinedDate: 'Jul 22, 2024',
      lastActive: '15 minutes ago',
    ),
    const User(
      id: '8',
      fullName: 'Bilal Ahmed',
      username: 'bilalahmed',
      email: 'bilal32@gmail.com',
      role: 'User',
      isActive: false,
      joinedDate: 'Aug 3, 2024',
      lastActive: '2 weeks ago',
    ),
    const User(
      id: '9',
      fullName: 'Faisal Mahmood',
      username: 'faisalmahmood',
      email: 'FaisalMahmood009@gmail.com',
      role: 'User',
      isActive: false,
      joinedDate: 'Sep 18, 2024',
      lastActive: '1 month ago',
    ),
    const User(
      id: '10',
      fullName: 'Hira Shah',
      username: 'hirashah',
      email: 'HiraShah@gmail.com',
      role: 'User',
      isActive: false,
      joinedDate: 'Oct 25, 2024',
      lastActive: '3 days ago',
    ),
    const User(
      id: '11',
      fullName: 'Umaira Ali',
      username: 'umairaali',
      email: 'umaira_alii99@gmail.com',
      role: 'User',
      isActive: false,
      joinedDate: 'Nov 10, 2024',
      lastActive: '1 week ago',
    ),
  ];

  List<User> get allUsers => _users;

  List<User> get filteredUsers {
    var users = allUsers;

    // Apply search filter
    if (_searchQuery.isNotEmpty) {
      final query = _searchQuery.toLowerCase();
      users = users.where((user) {
        return user.fullName.toLowerCase().contains(query) ||
            user.email.toLowerCase().contains(query) ||
            user.username.toLowerCase().contains(query);
      }).toList();
    }

    // Apply role filter
    if (_selectedRole != null && _selectedRole!.isNotEmpty) {
      users = users.where((user) => user.role == _selectedRole).toList();
    }

    // Apply status filter
    if (_selectedStatus != null && _selectedStatus!.isNotEmpty) {
      if (_selectedStatus == 'Active') {
        users = users.where((user) => user.isActive == true).toList();
      } else if (_selectedStatus == 'Inactive') {
        users = users.where((user) => user.isActive == false).toList();
      }
    }

    // Apply date filter
    if (_selectedDate != null && _selectedDate!.isNotEmpty) {
      final now = DateTime.now();
      users = users.where((user) {
        // Parse joined date (format: "Jan 15, 2024")
        try {
          final dateParts = user.joinedDate.split(' ');
          if (dateParts.length >= 3) {
            final month = dateParts[0];
            final day = int.tryParse(dateParts[1].replaceAll(',', '')) ?? 0;
            final year = int.tryParse(dateParts[2]) ?? 0;

            final monthMap = {
              'Jan': 1,
              'Feb': 2,
              'Mar': 3,
              'Apr': 4,
              'May': 5,
              'Jun': 6,
              'Jul': 7,
              'Aug': 8,
              'Sep': 9,
              'Oct': 10,
              'Nov': 11,
              'Dec': 12
            };
            final monthNum = monthMap[month] ?? 1;
            final userDate = DateTime(year, monthNum, day);
            final difference = now.difference(userDate).inDays;

            switch (_selectedDate) {
              case 'Today':
                return difference == 0;
              case 'This Week':
                return difference <= 7;
              case 'This Month':
                return difference <= 30;
              default:
                return true;
            }
          }
        } catch (e) {
          return true; // If parsing fails, include the user
        }
        return true;
      }).toList();
    }

    // Sort by name
    users.sort((a, b) {
      if (_isNameSortAscending) {
        return a.fullName.compareTo(b.fullName);
      } else {
        return b.fullName.compareTo(a.fullName);
      }
    });

    return users;
  }

  int get activeUsersCount => allUsers.where((u) => u.isActive).length;
  int get inactiveUsersCount => allUsers.where((u) => !u.isActive).length;

  void updateSearchQuery(String query) {
    _searchQuery = query;
    state = SuccessState({'searchQuery': _searchQuery, 'filtered': true});
  }

  void updateRoleFilter(String? role) {
    _selectedRole = role;
    state = SuccessState({'selectedRole': _selectedRole, 'filtered': true});
  }

  void updateStatusFilter(String? status) {
    _selectedStatus = status;
    state = SuccessState({'selectedStatus': _selectedStatus, 'filtered': true});
  }

  void updateDateFilter(String? date) {
    _selectedDate = date;
    state = SuccessState({'selectedDate': _selectedDate, 'filtered': true});
  }

  void toggleNameSort() {
    _isNameSortAscending = !_isNameSortAscending;
    state = SuccessState({'isNameSortAscending': _isNameSortAscending});
  }

  void toggleUserSelection(String userId) {
    if (_selectedUserIds.contains(userId)) {
      _selectedUserIds.remove(userId);
    } else {
      _selectedUserIds.add(userId);
    }
    state = SuccessState({'selectedUserIds': _selectedUserIds});
  }

  void selectAllUsers() {
    if (_selectedUserIds.length == filteredUsers.length) {
      _selectedUserIds.clear();
    } else {
      _selectedUserIds = filteredUsers.map((u) => u.id).toSet();
    }
    state = SuccessState({'selectedUserIds': _selectedUserIds});
  }

  Future<void> loadUsers() async {
    setLoading();
    try {
      // TODO: Fetch actual data from API
      await Future.delayed(const Duration(seconds: 1));
      setSuccess();
    } catch (e) {
      setError(e.toString());
    }
  }

  void deleteUser(String userId) {
    _users.removeWhere((user) => user.id == userId);
    // Also remove from selected users if it was selected
    _selectedUserIds.remove(userId);
    // Force state update to refresh UI
    state = SuccessState({
      'deleted': userId,
      'users': _users,
      'refresh': DateTime.now().millisecondsSinceEpoch
    });
  }

  void addUser(User user) {
    _users.add(user);
    state = SuccessState({
      'added': user.id,
      'users': _users,
      'refresh': DateTime.now().millisecondsSinceEpoch
    });
  }

  void updateUser(User updatedUser) {
    final index = _users.indexWhere((user) => user.id == updatedUser.id);
    if (index != -1) {
      _users[index] = updatedUser;
      state = SuccessState({
        'updated': updatedUser.id,
        'users': _users,
        'refresh': DateTime.now().millisecondsSinceEpoch
      });
    }
  }

  User? getUserById(String userId) {
    try {
      return _users.firstWhere((user) => user.id == userId);
    } catch (e) {
      return null;
    }
  }
}

/// User Management ViewModel Provider
final userManagementViewModelProvider =
    StateNotifierProvider<UserManagementViewModel, ViewModelState>((ref) {
  return UserManagementViewModel();
});
