import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../home/presentation/widgets/admin_navigation_drawer.dart';
import 'viewmodels/user_management_viewmodel.dart';
import 'widgets/user_count_card.dart';
import 'widgets/filter_dropdown.dart';

/// User Management Screen
class UserManagementScreen extends ConsumerStatefulWidget {
  const UserManagementScreen({super.key});

  @override
  ConsumerState<UserManagementScreen> createState() =>
      _UserManagementScreenState();
}

class _UserManagementScreenState extends ConsumerState<UserManagementScreen> {
  final _searchController = TextEditingController();
  final ScrollController _horizontalScrollController = ScrollController();

  @override
  void dispose() {
    _searchController.dispose();
    _horizontalScrollController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(userManagementViewModelProvider.notifier).loadUsers();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(userManagementViewModelProvider.notifier);
    // Watch state to trigger UI refresh on changes
    ref.watch(userManagementViewModelProvider);

    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      drawer: const AdminNavigationDrawer(),
      body: SafeArea(
        child: Column(
          children: [
            // Header
            _buildHeader(context),
            // Content
            Expanded(
              child: SingleChildScrollView(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: AppSizes.spacingL),
                      // Title and Description
                      _buildTitleSection(context),
                      const SizedBox(height: AppSizes.spacingL),
                      // User Count Cards
                      _buildUserCountCards(context, viewModel),
                      const SizedBox(height: AppSizes.spacingL),
                      // Search and Add User
                      _buildSearchAndAddBar(context, viewModel),
                      const SizedBox(height: AppSizes.spacingM),
                      // Filter Options
                      _buildFilterOptions(context, viewModel),
                      const SizedBox(height: AppSizes.spacingL),
                      // User List Table
                      _buildUserTable(context, viewModel),
                      const SizedBox(height: AppSizes.spacingXL),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Hamburger Menu
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.darkBlue),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
          // Logo and USL
          Row(
            children: [
              Image.asset(
                'assets/images/Asset 2 2.png',
                width: 40,
                height: 40,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: AppSizes.spacingS),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'USL Admin Portal',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: AppColors.darkBlue,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                        ),
                  ),
                  Text(
                    'Sign Language Recognition System',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.lightBlueText,
                          fontSize: 12,
                        ),
                  ),
                ],
              ),
            ],
          ),
          // Refresh Icon
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(AppSizes.spacingS),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey[200],
              ),
              child: const Icon(
                Icons.refresh,
                color: AppColors.darkBlue,
                size: AppSizes.iconS,
              ),
            ),
            onPressed: () {
              ref.read(userManagementViewModelProvider.notifier).loadUsers();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTitleSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'User Management',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: AppColors.darkBlue,
                fontWeight: FontWeight.bold,
                fontSize: 28,
              ),
        ),
        const SizedBox(height: AppSizes.spacingXS),
        Text(
          'Manage and monitor all registered users in the system',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.lightBlueText,
                fontSize: 14,
              ),
        ),
      ],
    );
  }

  Widget _buildUserCountCards(
      BuildContext context, UserManagementViewModel viewModel) {
    return Row(
      children: [
        Expanded(
          child: UserCountCard(
            label: 'Active',
            count: viewModel.activeUsersCount,
            backgroundColor: Colors.green,
          ),
        ),
        const SizedBox(width: AppSizes.spacingM),
        Expanded(
          child: UserCountCard(
            label: 'Inactive',
            count: viewModel.inactiveUsersCount,
            backgroundColor: Colors.grey,
          ),
        ),
      ],
    );
  }

  Widget _buildSearchAndAddBar(
      BuildContext context, UserManagementViewModel viewModel) {
    return Row(
      children: [
        // Search Bar
        Expanded(
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(AppSizes.radiusM),
              border: Border.all(color: Colors.grey[300]!),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search',
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: AppSizes.spacingM,
                  vertical: AppSizes.spacingM,
                ),
              ),
              onChanged: (value) => viewModel.updateSearchQuery(value),
            ),
          ),
        ),
        const SizedBox(width: AppSizes.spacingM),
        // Add User Button
        Container(
          constraints: const BoxConstraints(
            minWidth: 100,
            maxWidth: 150,
          ),
          child: ElevatedButton(
            onPressed: () => _handleAddUser(context, viewModel),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.handBlue,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: AppSizes.spacingM,
                vertical: AppSizes.spacingM,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(AppSizes.radiusM),
              ),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.add, color: Colors.white, size: 18),
                SizedBox(width: AppSizes.spacingXS),
                Flexible(
                  child: Text(
                    'Add User',
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFilterOptions(
      BuildContext context, UserManagementViewModel viewModel) {
    return Row(
      children: [
        Expanded(
          child: FilterDropdown(
            icon: Icons.person,
            label: 'Role',
            selectedValue: viewModel.selectedRole,
            options: const ['All', 'User', 'Admin'],
            onChanged: (value) =>
                viewModel.updateRoleFilter(value == 'All' ? null : value),
          ),
        ),
        const SizedBox(width: AppSizes.spacingS),
        Expanded(
          child: FilterDropdown(
            icon: Icons.flag,
            label: 'Status',
            selectedValue: viewModel.selectedStatus,
            options: const ['All', 'Active', 'Inactive'],
            onChanged: (value) {
              viewModel.updateStatusFilter(value == 'All' ? null : value);
            },
          ),
        ),
        const SizedBox(width: AppSizes.spacingS),
        Expanded(
          child: FilterDropdown(
            icon: Icons.calendar_today,
            label: 'Date',
            selectedValue: viewModel.selectedDate,
            options: const ['All', 'Today', 'This Week', 'This Month'],
            onChanged: (value) =>
                viewModel.updateDateFilter(value == 'All' ? null : value),
          ),
        ),
      ],
    );
  }

  Widget _buildUserTable(
      BuildContext context, UserManagementViewModel viewModel) {
    final users = viewModel.filteredUsers;
    final allSelected = users.isNotEmpty &&
        users.every((user) => viewModel.selectedUserIds.contains(user.id));

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppSizes.radiusM),
      ),
      child: SingleChildScrollView(
        controller: _horizontalScrollController,
        scrollDirection: Axis.horizontal,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Table Header
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSizes.spacingS,
                vertical: AppSizes.spacingS,
              ),
              decoration: BoxDecoration(
                color: AppColors.handBlue,
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(AppSizes.radiusM),
                  topRight: Radius.circular(AppSizes.radiusM),
                ),
              ),
              child: Row(
                children: [
                  Checkbox(
                    value: allSelected,
                    onChanged: (value) => viewModel.selectAllUsers(),
                    activeColor: Colors.white,
                    checkColor: AppColors.handBlue,
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  const SizedBox(width: AppSizes.spacingXS),
                  _buildHeaderCell(context, 'Full Name', 120,
                      isSortable: true, viewModel: viewModel),
                  _buildHeaderCell(context, 'Username', 100),
                  _buildHeaderCell(context, 'Email', 150),
                  _buildHeaderCell(context, 'Status', 80),
                  _buildHeaderCell(context, 'Role', 80),
                  _buildHeaderCell(context, 'Joined Date', 100),
                  _buildHeaderCell(context, 'Last Active', 100),
                  _buildHeaderCell(context, 'Actions', 100),
                ],
              ),
            ),
            // Table Rows
            ...users.map((user) {
              final isSelected = viewModel.selectedUserIds.contains(user.id);
              return Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppSizes.spacingS,
                  vertical: AppSizes.spacingS,
                ),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: Colors.grey[200]!),
                  ),
                ),
                child: Row(
                  children: [
                    Checkbox(
                      value: isSelected,
                      onChanged: (value) =>
                          viewModel.toggleUserSelection(user.id),
                      activeColor: AppColors.handBlue,
                      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    ),
                    const SizedBox(width: AppSizes.spacingXS),
                    // Profile Picture
                    CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.grey[300],
                      backgroundImage:
                          const AssetImage('assets/images/User image.png'),
                      onBackgroundImageError: (exception, stackTrace) {
                        // Fallback handled by backgroundColor
                      },
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Full Name
                    SizedBox(
                      width: 120,
                      child: Text(
                        user.fullName,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: 12,
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Username
                    SizedBox(
                      width: 100,
                      child: Text(
                        user.username,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: 12,
                              color: Colors.grey[700],
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Email
                    SizedBox(
                      width: 150,
                      child: Text(
                        user.email,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Colors.grey[600],
                              fontSize: 11,
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Status
                    SizedBox(
                      width: 80,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppSizes.spacingXS,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: user.isActive
                              ? Colors.green[100]
                              : Colors.grey[300],
                          borderRadius: BorderRadius.circular(AppSizes.radiusS),
                        ),
                        child: Text(
                          user.isActive ? 'Active' : 'Inactive',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: user.isActive
                                        ? Colors.green[800]
                                        : Colors.grey[700],
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                  ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Role
                    SizedBox(
                      width: 80,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: AppSizes.spacingXS,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: user.role == 'Admin'
                              ? AppColors.primaryContainer
                              : AppColors.darkBlue.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(AppSizes.radiusS),
                        ),
                        child: Text(
                          user.role,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: user.role == 'Admin'
                                        ? AppColors.primary
                                        : AppColors.darkBlue,
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                  ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Joined Date
                    SizedBox(
                      width: 100,
                      child: Text(
                        user.joinedDate,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: 11,
                              color: Colors.grey[600],
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Last Active
                    SizedBox(
                      width: 100,
                      child: Text(
                        user.lastActive,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              fontSize: 11,
                              color: Colors.grey[600],
                            ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: AppSizes.spacingS),
                    // Actions
                    SizedBox(
                      width: 100,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.edit,
                                size: 18, color: AppColors.handBlue),
                            onPressed: () =>
                                _handleEditUser(context, viewModel, user),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                          const SizedBox(width: AppSizes.spacingXS),
                          IconButton(
                            icon: const Icon(Icons.delete,
                                size: 18, color: Colors.red),
                            onPressed: () =>
                                _handleDeleteUser(context, viewModel, user),
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderCell(
    BuildContext context,
    String title,
    double width, {
    bool isSortable = false,
    UserManagementViewModel? viewModel,
  }) {
    return SizedBox(
      width: width,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Text(
              title,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          if (isSortable && viewModel != null) ...[
            const SizedBox(width: AppSizes.spacingXS),
            IconButton(
              icon: Icon(
                viewModel.isNameSortAscending
                    ? Icons.arrow_upward
                    : Icons.arrow_downward,
                color: Colors.white,
                size: 16,
              ),
              onPressed: () => viewModel.toggleNameSort(),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
          ],
        ],
      ),
    );
  }

  void _handleEditUser(
      BuildContext context, UserManagementViewModel viewModel, User user) {
    final firstNameController =
        TextEditingController(text: user.fullName.split(' ').first);
    final lastNameController = TextEditingController(
        text: user.fullName.split(' ').length > 1
            ? user.fullName.split(' ').sublist(1).join(' ')
            : '');
    final usernameController = TextEditingController(text: user.username);
    final emailController = TextEditingController(text: user.email);
    String selectedRole = user.role;
    bool isActive = user.isActive;
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Edit User'),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: firstNameController,
                    decoration: const InputDecoration(
                      labelText: 'First Name',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: lastNameController,
                    decoration: const InputDecoration(
                      labelText: 'Last Name',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: usernameController,
                    decoration: const InputDecoration(
                      labelText: 'Username',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value?.isEmpty ?? true) return 'Required';
                      if (!value!.contains('@')) return 'Invalid email';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: selectedRole,
                    decoration: const InputDecoration(
                      labelText: 'Role',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'User', child: Text('User')),
                      DropdownMenuItem(value: 'Admin', child: Text('Admin')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => selectedRole = value);
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text('Status: '),
                      Switch(
                        value: isActive,
                        onChanged: (value) => setState(() => isActive = value),
                      ),
                      Text(isActive ? 'Active' : 'Inactive'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  final updatedUser = User(
                    id: user.id,
                    fullName:
                        '${firstNameController.text} ${lastNameController.text}'
                            .trim(),
                    username: usernameController.text,
                    email: emailController.text,
                    role: selectedRole,
                    isActive: isActive,
                    joinedDate: user.joinedDate,
                    lastActive: user.lastActive,
                    profileImageUrl: user.profileImageUrl,
                  );
                  viewModel.updateUser(updatedUser);
                  Navigator.of(context).pop();
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content:
                          Text('${updatedUser.fullName} updated successfully'),
                      backgroundColor: Colors.green,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _handleDeleteUser(
    BuildContext context,
    UserManagementViewModel viewModel,
    User user,
  ) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete User'),
        content: Text(
            'Are you sure you want to delete ${user.fullName}? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(context).pop();
              viewModel.deleteUser(user.id);
              // Force UI refresh
              setState(() {});
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('${user.fullName} deleted successfully'),
                  backgroundColor: Colors.green,
                  duration: const Duration(seconds: 2),
                ),
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  void _handleAddUser(BuildContext context, UserManagementViewModel viewModel) {
    final firstNameController = TextEditingController();
    final lastNameController = TextEditingController();
    final usernameController = TextEditingController();
    final emailController = TextEditingController();
    String selectedRole = 'User';
    bool isActive = true;
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Add New User'),
          content: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: firstNameController,
                    decoration: const InputDecoration(
                      labelText: 'First Name',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: lastNameController,
                    decoration: const InputDecoration(
                      labelText: 'Last Name',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: usernameController,
                    decoration: const InputDecoration(
                      labelText: 'Username',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) =>
                        value?.isEmpty ?? true ? 'Required' : null,
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value?.isEmpty ?? true) return 'Required';
                      if (!value!.contains('@')) return 'Invalid email';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: selectedRole,
                    decoration: const InputDecoration(
                      labelText: 'Role',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: 'User', child: Text('User')),
                      DropdownMenuItem(value: 'Admin', child: Text('Admin')),
                    ],
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => selectedRole = value);
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Text('Status: '),
                      Switch(
                        value: isActive,
                        onChanged: (value) => setState(() => isActive = value),
                      ),
                      Text(isActive ? 'Active' : 'Inactive'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (formKey.currentState!.validate()) {
                  // Generate a new ID
                  final newId =
                      DateTime.now().millisecondsSinceEpoch.toString();
                  final now = DateTime.now();
                  final monthNames = [
                    'Jan',
                    'Feb',
                    'Mar',
                    'Apr',
                    'May',
                    'Jun',
                    'Jul',
                    'Aug',
                    'Sep',
                    'Oct',
                    'Nov',
                    'Dec'
                  ];
                  final formattedDate =
                      '${monthNames[now.month - 1]} ${now.day}, ${now.year}';

                  final newUser = User(
                    id: newId,
                    fullName:
                        '${firstNameController.text} ${lastNameController.text}'
                            .trim(),
                    username: usernameController.text,
                    email: emailController.text,
                    role: selectedRole,
                    isActive: isActive,
                    joinedDate: formattedDate,
                    lastActive: 'Just now',
                  );
                  viewModel.addUser(newUser);
                  Navigator.of(context).pop();
                  // Force UI refresh
                  setState(() {});
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${newUser.fullName} added successfully'),
                      backgroundColor: Colors.green,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );
  }
}
