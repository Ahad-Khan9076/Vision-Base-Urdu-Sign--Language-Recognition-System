import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_routes.dart';
import '../../../../core/constants/app_sizes.dart';

/// Splash screen - First screen shown when app launches
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  void _navigateToRoleSelection(BuildContext context) {
    context.go(AppRoutes.roleSelection);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingL),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Spacer(flex: 2),
              // Logo Image
              Center(
                child: Image.asset(
                  'assets/images/Asset 2 2.png',
                  width: 200,
                  height: 200,
                  fit: BoxFit.contain,
                ),
              ),
              const SizedBox(height: AppSizes.spacingXXL),
              // Main Title
              Text(
                'Sign Language recognition',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: AppColors.darkBlue,
                      fontWeight: FontWeight.bold,
                      fontSize: 28,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: AppSizes.spacingM),
              // Subtitle
              Text(
                'Bridging communication for the deaf community',
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                      color: AppColors.lightBlueText,
                      fontSize: 16,
                    ),
                textAlign: TextAlign.center,
              ),
              const Spacer(flex: 3),
              // Get Started Button
              SizedBox(
                width: double.infinity,
                height: AppSizes.buttonHeightL,
                child: ElevatedButton(
                  onPressed: () => _navigateToRoleSelection(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.orange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(AppSizes.radiusM),
                    ),
                    elevation: 0,
                  ),
                  child: Text(
                    'Get Started',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
              ),
              const SizedBox(height: AppSizes.spacingXL),
            ],
          ),
        ),
      ),
    );
  }
}

