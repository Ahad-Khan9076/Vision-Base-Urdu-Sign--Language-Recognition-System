import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../home/presentation/widgets/admin_navigation_drawer.dart';
import 'viewmodels/analytics_viewmodel.dart';
import 'widgets/analytics_kpi_card.dart';
import 'widgets/sign_usage_distribution_chart.dart';
import 'widgets/daily_activity_pattern_chart.dart';
import 'widgets/daily_activity_log_table.dart';

/// Analytics & Monitoring Screen
class AnalyticsScreen extends ConsumerStatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  ConsumerState<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends ConsumerState<AnalyticsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(analyticsViewModelProvider.notifier).loadAnalyticsData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final viewModel = ref.watch(analyticsViewModelProvider.notifier);

    return Scaffold(
      backgroundColor: AppColors.beigeBackground,
      drawer: const AdminNavigationDrawer(),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Header
              _buildHeader(context),
              // Content
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: AppSizes.spacingL),
                    // Title Section
                    _buildTitleSection(context),
                    const SizedBox(height: AppSizes.spacingL),
                    // KPI Cards Grid
                    _buildKPIGrid(context),
                    const SizedBox(height: AppSizes.spacingL),
                    // Sign Usage Distribution Chart
                    SignUsageDistributionChart(
                      data: viewModel.signUsageData,
                      viewModel: viewModel,
                    ),
                    const SizedBox(height: AppSizes.spacingL),
                    // Daily Activity Pattern Chart
                    DailyActivityPatternChart(data: viewModel.hourlyActivityData),
                    const SizedBox(height: AppSizes.spacingL),
                    // Daily Activity Log Table
                    DailyActivityLogTable(data: viewModel.dailyActivityLog),
                    const SizedBox(height: AppSizes.spacingXL),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSizes.spacingM),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Hamburger Menu
          Builder(
            builder: (context) => IconButton(
              icon: const Icon(Icons.menu, color: AppColors.darkBlue),
              onPressed: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
          // Logo and USL
          Row(
            children: [
              Image.asset(
                'assets/images/Asset 2 2.png',
                width: 40,
                height: 40,
                fit: BoxFit.contain,
              ),
              const SizedBox(width: AppSizes.spacingS),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'USL ',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                color: AppColors.orange,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                        ),
                        TextSpan(
                          text: 'Admin Portal',
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                color: AppColors.darkBlue,
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                        ),
                      ],
                    ),
                  ),
                  Text(
                    'Sign Language Recognition System',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppColors.lightBlueText,
                          fontSize: 12,
                        ),
                  ),
                ],
              ),
            ],
          ),
          // Refresh Icon
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(AppSizes.spacingS),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.grey[200],
              ),
              child: const Icon(
                Icons.refresh,
                color: AppColors.darkBlue,
                size: AppSizes.iconS,
              ),
            ),
            onPressed: () {
              ref.read(analyticsViewModelProvider.notifier).loadAnalyticsData();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildTitleSection(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Analytics & Monitoring',
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: AppColors.darkBlue,
                fontWeight: FontWeight.bold,
                fontSize: 28,
              ),
        ),
        const SizedBox(height: AppSizes.spacingXS),
        Text(
          'Comprehensive system usage statistics and performance insights',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppColors.orange,
                fontSize: 14,
              ),
        ),
      ],
    );
  }

  Widget _buildKPIGrid(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: AppSizes.spacingM,
      mainAxisSpacing: AppSizes.spacingM,
      childAspectRatio: 1.2,
      children: [
        AnalyticsKPICard(
          title: 'Recognition Rate',
          value: '94.7%',
          change: '+2.3%',
          isPositive: true,
        ),
        AnalyticsKPICard(
          title: 'Avg Session',
          value: '8.4 min',
          change: '+12%',
          isPositive: true,
        ),
        AnalyticsKPICard(
          title: 'New Users Today',
          value: '23',
          change: '-5%',
          isPositive: false,
        ),
        AnalyticsKPICard(
          title: 'System Uptime',
          value: '99.9%',
          status: 'Live',
        ),
      ],
    );
  }
}


