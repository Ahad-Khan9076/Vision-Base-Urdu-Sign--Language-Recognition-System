import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/base/base_viewmodel.dart';

/// Sign Usage Data Model
class SignUsageData {
  final String sign;
  final Map<String, double> monthlyData; // Month -> Count

  const SignUsageData({
    required this.sign,
    required this.monthlyData,
  });
}

/// Daily Activity Data Model
class DailyActivityData {
  final String date;
  final int activeUsers;
  final String signsPerformed;
  final String avgPerUser;

  const DailyActivityData({
    required this.date,
    required this.activeUsers,
    required this.signsPerformed,
    required this.avgPerUser,
  });
}

/// Hourly Activity Data Model
class HourlyActivityData {
  final int hour;
  final double thisWeek;
  final double lastWeek;

  const HourlyActivityData({
    required this.hour,
    required this.thisWeek,
    required this.lastWeek,
  });
}

/// Analytics ViewModel
class AnalyticsViewModel extends BaseViewModel {
  AnalyticsViewModel() : super();

  List<SignUsageData> get signUsageData => [
        // Light blue/teal line with shaded area (starts between "Thank you" and "I am sick" in Jan)
        SignUsageData(
          sign: 'Thank you',
          monthlyData: {
            'Jan': 0.85,  // Between "I am sick" (0.67) and "Thank you" (1.0)
            'Feb': 0.72,  // Peak just above "I am sick" (0.67)
            'Mar': 0.65,  // Below "I am sick"
            'Apr': 0.60,  // Below "I am sick"
            'May': 0.67,  // At "I am sick"
            'Jun': 0.62,  // Below "I am sick"
            'Jul': 0.67,  // At "I am sick"
            'Aug': 0.65,  // Slightly below "I am sick"
          },
        ),
        // Purple/darker blue line (starts around May, peaks well above "How long" in July)
        SignUsageData(
          sign: 'How long',
          monthlyData: {
            'Jan': 0.0,
            'Feb': 0.0,
            'Mar': 0.0,
            'Apr': 0.0,
            'May': 0.70,  // Slightly above light blue (0.67)
            'Jun': 0.50,  // Between "How long" (0.33) and "I am sick" (0.67)
            'Jul': 0.88,  // Well above "How long" (0.33) - peaks high
            'Aug': 0.70,  // Just above "I am sick" (0.67)
          },
        ),
      ];

  // Y-axis positions for signs (0.0 to 1.0 scale)
  Map<String, double> get signYPositions => {
        'It is fine': 0.0,
        'How long': 0.33,
        'I am sick': 0.67,
        'Thank you': 1.0,
      };

  List<HourlyActivityData> get hourlyActivityData => [
        // Solid dark gray line (thisWeek) - starts around 250, rises slightly to peak just below 300, dips significantly to ~150, rises steadily to end just below 300
        // Dashed light blue line (lastWeek) - starts below 250, rises to just above 250, maintains flat between 250-275, then rises sharply to peak above 400
        const HourlyActivityData(hour: 0, thisWeek: 250, lastWeek: 220),
        const HourlyActivityData(hour: 1, thisWeek: 255, lastWeek: 240),
        const HourlyActivityData(hour: 2, thisWeek: 260, lastWeek: 250),
        const HourlyActivityData(hour: 3, thisWeek: 265, lastWeek: 255),
        const HourlyActivityData(hour: 4, thisWeek: 270, lastWeek: 260),
        const HourlyActivityData(hour: 5, thisWeek: 275, lastWeek: 265),
        const HourlyActivityData(hour: 6, thisWeek: 280, lastWeek: 270),
        const HourlyActivityData(hour: 7, thisWeek: 285, lastWeek: 275),
        const HourlyActivityData(hour: 8, thisWeek: 290, lastWeek: 275),
        const HourlyActivityData(hour: 9, thisWeek: 295, lastWeek: 275),
        const HourlyActivityData(hour: 10, thisWeek: 280, lastWeek: 275),
        const HourlyActivityData(hour: 11, thisWeek: 250, lastWeek: 275),
        const HourlyActivityData(hour: 12, thisWeek: 200, lastWeek: 275),
        const HourlyActivityData(hour: 13, thisWeek: 170, lastWeek: 280),
        const HourlyActivityData(hour: 14, thisWeek: 150, lastWeek: 285),
        const HourlyActivityData(hour: 15, thisWeek: 160, lastWeek: 290),
        const HourlyActivityData(hour: 16, thisWeek: 180, lastWeek: 300),
        const HourlyActivityData(hour: 17, thisWeek: 200, lastWeek: 320),
        const HourlyActivityData(hour: 18, thisWeek: 220, lastWeek: 350),
        const HourlyActivityData(hour: 19, thisWeek: 240, lastWeek: 380),
        const HourlyActivityData(hour: 20, thisWeek: 260, lastWeek: 400),
        const HourlyActivityData(hour: 21, thisWeek: 275, lastWeek: 420),
        const HourlyActivityData(hour: 22, thisWeek: 285, lastWeek: 450),
        const HourlyActivityData(hour: 23, thisWeek: 290, lastWeek: 480),
      ];

  List<DailyActivityData> get dailyActivityLog => [
        const DailyActivityData(
          date: 'Thu, Dec 12',
          activeUsers: 223,
          signsPerformed: '5,234',
          avgPerUser: '23',
        ),
        const DailyActivityData(
          date: 'Sat, Dec 14',
          activeUsers: 156,
          signsPerformed: '3,654',
          avgPerUser: '23',
        ),
        const DailyActivityData(
          date: 'Sun, Dec 15',
          activeUsers: 178,
          signsPerformed: '4,123',
          avgPerUser: '23',
        ),
        const DailyActivityData(
          date: 'Mon, Dec 16',
          activeUsers: 134,
          signsPerformed: '5,234',
          avgPerUser: '23',
        ),
        const DailyActivityData(
          date: 'Tue, Dec 17',
          activeUsers: 189,
          signsPerformed: '2,987',
          avgPerUser: '23',
        ),
        const DailyActivityData(
          date: 'Wed, Dec 18',
          activeUsers: 145,
          signsPerformed: '3,654',
          avgPerUser: '23',
        ),
      ];

  Future<void> loadAnalyticsData() async {
    setLoading();
    try {
      // TODO: Fetch actual data from API
      await Future.delayed(const Duration(seconds: 1));
      setSuccess();
    } catch (e) {
      setError(e.toString());
    }
  }
}

/// Analytics ViewModel Provider
final analyticsViewModelProvider =
    StateNotifierProvider<AnalyticsViewModel, ViewModelState>((ref) {
  return AnalyticsViewModel();
});


