import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../../core/constants/app_sizes.dart';
import '../viewmodels/analytics_viewmodel.dart';

/// Daily Activity Pattern Line Chart
class DailyActivityPatternChart extends StatelessWidget {
  final List<HourlyActivityData> data;

  const DailyActivityPatternChart({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.spacingM),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppSizes.radiusM),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Daily Activity Pattern',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
              ),
              Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: Colors.black,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: AppSizes.spacingXS),
                  Text(
                    '24 Hours',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontSize: 11,
                        ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: AppSizes.spacingXS),
          Text(
            'Peak usage hours throughout the day',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey[600],
                  fontSize: 12,
                ),
          ),
          const SizedBox(height: AppSizes.spacingM),
          SizedBox(
            height: 250,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 750,
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: false,
                  horizontalInterval: 250,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: Colors.grey[300]!,
                      strokeWidth: 1,
                      dashArray: [5, 5],
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 40,
                      getTitlesWidget: (value, meta) {
                        if (value == 0) return const Text('0', style: TextStyle(fontSize: 11));
                        if (value == 250) return const Text('250', style: TextStyle(fontSize: 11));
                        if (value == 500) return const Text('500', style: TextStyle(fontSize: 11));
                        if (value == 750) return const Text('750', style: TextStyle(fontSize: 11));
                        return const Text('');
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: false, // Hide hour labels as per screenshot
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  // Solid dark gray line (thisWeek)
                  LineChartBarData(
                    spots: data.map((e) => FlSpot(e.hour.toDouble(), e.thisWeek)).toList(),
                    isCurved: true,
                    color: Colors.grey[800],
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                  ),
                  // Dashed light blue line (lastWeek)
                  LineChartBarData(
                    spots: data.map((e) => FlSpot(e.hour.toDouble(), e.lastWeek)).toList(),
                    isCurved: true,
                    color: const Color(0xFF64B5F6), // Light blue
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                    dashArray: [5, 5],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
