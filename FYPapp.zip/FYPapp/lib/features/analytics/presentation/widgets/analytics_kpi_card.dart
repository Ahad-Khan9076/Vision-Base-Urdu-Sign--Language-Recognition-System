import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_sizes.dart';

/// Analytics KPI Card widget
class AnalyticsKPICard extends StatelessWidget {
  final String title;
  final String value;
  final String? change;
  final bool isPositive;
  final String? status;

  const AnalyticsKPICard({
    super.key,
    required this.title,
    required this.value,
    this.change,
    this.isPositive = true,
    this.status,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppSizes.spacingM),
      decoration: BoxDecoration(
        color: AppColors.handBlue,
        borderRadius: BorderRadius.circular(AppSizes.radiusM),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Colors.white.withOpacity(0.9),
                        fontSize: 12,
                      ),
                ),
              ),
              Icon(
                Icons.show_chart,
                color: Colors.white.withOpacity(0.7),
                size: AppSizes.iconS,
              ),
            ],
          ),
          const SizedBox(height: AppSizes.spacingS),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 24,
                ),
          ),
          if (change != null) ...[
            const SizedBox(height: AppSizes.spacingXS),
            Text(
              change!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: isPositive ? Colors.green[300] : Colors.red[300],
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
          if (status != null) ...[
            const SizedBox(height: AppSizes.spacingXS),
            Text(
              status!,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Colors.green[300],
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                  ),
            ),
          ],
        ],
      ),
    );
  }
}


