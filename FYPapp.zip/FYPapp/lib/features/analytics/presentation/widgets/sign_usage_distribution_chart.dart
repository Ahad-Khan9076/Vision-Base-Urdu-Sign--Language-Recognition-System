import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../../core/constants/app_sizes.dart';
import '../viewmodels/analytics_viewmodel.dart';

/// Sign Usage Distribution Line Chart
class SignUsageDistributionChart extends StatelessWidget {
  final List<SignUsageData> data;
  final AnalyticsViewModel viewModel;

  const SignUsageDistributionChart({
    super.key,
    required this.data,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'];

    return Container(
      padding: const EdgeInsets.all(AppSizes.spacingM),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(AppSizes.radiusM),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Sign Usage Distribution',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: AppSizes.spacingM),
          SizedBox(
            height: 300,
            child: LineChart(
              LineChartData(
                minY: 0,
                maxY: 1.0,
                minX: 0,
                maxX: 7,
                gridData: FlGridData(
                  show: true,
                  drawVerticalLine: true,
                  drawHorizontalLine: true,
                  horizontalInterval: 1.0 / 3.0,
                  verticalInterval: 1.0,
                  getDrawingHorizontalLine: (value) {
                    return FlLine(
                      color: Colors.grey[300]!,
                      strokeWidth: 1,
                      dashArray: [5, 5],
                    );
                  },
                  getDrawingVerticalLine: (value) {
                    return FlLine(
                      color: Colors.grey[300]!,
                      strokeWidth: 1,
                      dashArray: [5, 5],
                    );
                  },
                ),
                titlesData: FlTitlesData(
                  leftTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      reservedSize: 90,
                      interval: 1.0 / 3.0,
                      getTitlesWidget: (value, meta) {
                        // Map Y values to sign names with exact positions
                        if ((value - 0.0).abs() < 0.01) {
                          return Padding(
                            padding: const EdgeInsets.only(right: AppSizes.spacingS),
                            child: Text(
                              'It is fine',
                              style: const TextStyle(fontSize: 11, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          );
                        } else if ((value - 0.333).abs() < 0.01) {
                          return Padding(
                            padding: const EdgeInsets.only(right: AppSizes.spacingS),
                            child: Text(
                              'How long',
                              style: const TextStyle(fontSize: 11, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          );
                        } else if ((value - 0.667).abs() < 0.01) {
                          return Padding(
                            padding: const EdgeInsets.only(right: AppSizes.spacingS),
                            child: Text(
                              'I am sick',
                              style: const TextStyle(fontSize: 11, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          );
                        } else if ((value - 1.0).abs() < 0.01) {
                          return Padding(
                            padding: const EdgeInsets.only(right: AppSizes.spacingS),
                            child: Text(
                              'Thank you',
                              style: const TextStyle(fontSize: 11, color: Colors.black87),
                              textAlign: TextAlign.right,
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      interval: 1.0,
                      getTitlesWidget: (value, meta) {
                        final index = value.toInt();
                        if (index >= 0 && index < months.length) {
                          return Text(
                            months[index],
                            style: const TextStyle(fontSize: 11, color: Colors.black87),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                lineBarsData: [
                  // Light blue/teal line with shaded area (Thank you line)
                  LineChartBarData(
                    spots: months.asMap().entries.map((monthEntry) {
                      final monthIndex = monthEntry.key;
                      final signData = data[0]; // First line (Thank you)
                      final yValue = signData.monthlyData[monthEntry.value] ?? 0.0;
                      // yValue is already mapped (0.0-1.0 scale where 0.67 = "I am sick", 1.0 = "Thank you")
                      return FlSpot(monthIndex.toDouble(), yValue);
                    }).toList(),
                    isCurved: true,
                    color: const Color(0xFF4DB6AC), // Teal/light blue
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                    aboveBarData: BarAreaData(
                      show: true,
                      color: const Color(0xFF4DB6AC).withOpacity(0.2),
                    ),
                  ),
                  // Purple/darker blue line (How long line)
                  LineChartBarData(
                    spots: months.asMap().entries.map((monthEntry) {
                      final monthIndex = monthEntry.key;
                      final signData = data[1]; // Second line (How long)
                      final yValue = signData.monthlyData[monthEntry.value] ?? 0.0;
                      // yValue is already mapped (0.0-1.0 scale)
                      return FlSpot(monthIndex.toDouble(), yValue);
                    }).toList(),
                    isCurved: true,
                    color: const Color(0xFF9C27B0), // Purple
                    barWidth: 3,
                    dotData: const FlDotData(show: false),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
