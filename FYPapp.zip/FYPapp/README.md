# Sign Language App

A production-ready Sign Language mobile application built with Flutter, following Clean Architecture principles.

## Architecture

- **Framework**: Flutter
- **State Management**: Riverpod
- **Architecture**: Clean Architecture (Presentation, Domain, Data)
- **Design Pattern**: MVVM
- **Principles**: SOLID

## Project Structure

```
lib/
├── core/                 # Core utilities and configurations
│   ├── constants/
│   ├── theme/
│   ├── utils/
│   └── widgets/
├── features/             # Feature modules
│   ├── splash/
│   ├── onboarding/
│   ├── auth/
│   ├── home/
│   ├── sign_detection/
│   ├── learning/
│   ├── practice/
│   └── profile/
│       ├── data/
│       ├── domain/
│       └── presentation/
└── main.dart
```

## Getting Started

1. Install dependencies:
```bash
flutter pub get
```

2. Generate code:
```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

3. Run the app:
```bash
flutter run
```

